# Application de recommendation de films

Cette application, sur la base de la base de données de imdb, permet de fournir des recommendations de films sur la base d'un seul film
